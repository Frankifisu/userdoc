# Calculate DOS for reconstructed and nonreconstructed Si(100) surfaces using HSE06
# These are computationally demanding calculations. Run them on a compute cluster.
# This file is part of the "Crystals and Surfaces" tutorial of the Amsterdam Modeling Suite
# USAGE: $AMSBIN/plams -f si100 si_reconstruction.py
# Then enter the si100/reconstructed and si100/nonreconstructed folders and run 
# $AMSBIN/amsdos band.rkf
# to view the DOS in the graphical user interface

mol_reconstructed = Molecule('si100_reconstructed.xyz') # optimized with PBE, keeping central layers fixed
mol_nonreconstructed = Molecule('si100_nonreconstructed.xyz') # cut out from the bulk crystal

s1 = Settings() # reconstructed
s1.input.ams.Task = 'SinglePoint'
s1.input.band.Basis.Type = 'DZP'
s1.input.band.Basis.Core = 'None'
s1.input.band.DOS.Enabled = 'Yes'
s1.input.band.XC.libxc = 'hse06'

s2 = s1.copy() #nonreconstructed
s2.input.band.Convergence.ElectronicTemperature = 0.000735

job_reconstructed = AMSJob(settings=s1, molecule=mol_reconstructed, name='reconstructed')
job_reconstructed.run()

job_nonreconstructed = AMSJob(settings=s2, molecule=mol_nonreconstructed, name='nonreconstructed')
job_nonreconstructed.run()

