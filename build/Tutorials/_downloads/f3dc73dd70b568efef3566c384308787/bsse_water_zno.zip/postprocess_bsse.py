#!/usr/bin/env plams
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

config.erase_workdir = True
jobs_dict = load_all('water_on_zno1010_bsse')

Ebind_uncorrected = []
Ebind_corrected = []
bsse = []
labels = []

for job_name in ['DZ', 'DZP', 'TZP', 'TZ2P', 'QZ4P']:
    for path,job in jobs_dict.items():
        if job.name != job_name or not isinstance(job, CounterpoiseEnergyJob):
            continue
        if job.ok():
            results = job.results.get_all_energies(unit='kcal/mol')
            print("#############")
            print("{} results (kcal/mol)".format(job.name))
            print("#############")
            for k,v in results.items():
                print("{} {:.2f}".format(k, v))
            #print(results) # to see all results
            Ebind_uncorrected.append(results['Ebind_raw'])
            Ebind_corrected.append(results['Ebind_cp'])
            bsse.append(results['BSSE_tot'])
            labels.append(job.name)
            print("")
            print("")

print("########")
print("SUMMARY")
print("########")
print("Basis, Ebind_uncorrected (kcal/mol), Ebind_corrected (kcal/mol), Counterpoise correction (kcal/mol)")
for basis, uncorrected, corrected, bs in zip(labels, Ebind_uncorrected, Ebind_corrected, bsse):
    print("{} {:.2f} {:.2f} {:.2f}".format(basis, uncorrected, corrected, -bs))


###### create plot
ind = list(range(len(Ebind_uncorrected)))

plt.plot(ind, Ebind_corrected, '-', label='Counterpoise-corrected')
plt.plot(ind, Ebind_uncorrected, '-', label='Uncorrected')
plt.title("H2O adsorption on ZnO(10-10)")
plt.ylabel("Adsorption energy (kcal/mol)")
plt.xlabel("Basis set")
plt.legend()
plt.xticks(ind, labels)
plt.savefig("plot.png")
