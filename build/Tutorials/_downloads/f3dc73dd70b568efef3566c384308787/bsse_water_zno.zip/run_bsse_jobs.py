# Calculate the adsorption energy of a water molecule on a ZnO substrate using progressively better basis sets
# For each basis set, evaluate the basis set superposition error
# This file is part of the "Crystals and Surfaces" tutorial of the Amsterdam Modeling Suite
# Usage: 
#    $AMSBIN/plams -f water_on_zno1010_bsse run_bsse_jobs.py
# Note: These are computationally demanding calculations. Run them on a compute cluster!

mol = Molecule('water-on-zno1010-tzp-optimized.xyz')

s = Settings()
s.input.ams.Task = 'GeometryOptimization'
s.input.BAND.Kspace.Quality = 'Basic'
s.input.BAND.XC.GGA = 'PBE'

for basis in ['DZ', 'DZP', 'TZP', 'TZ2P', 'QZ4P']:
    s.input.BAND.Basis.Type = basis
    ids_state_A = [1,2,3] # water molecule is atoms 1,2,3
    job = CounterpoiseEnergyJob(name=basis, AB=mol, ids_state_A=ids_state_A, settings_state_AB=s.copy())
    job.run()


