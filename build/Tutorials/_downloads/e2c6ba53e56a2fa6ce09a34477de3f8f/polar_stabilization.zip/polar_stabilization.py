# DFTB calculations on ZnO(0001) slabs
# bulk-terminated (clean), vacancy-stabilized, and adsorbate-stabilized
# This file is part of the "Crystals and Surfaces" tutorial in the Amsterdam Modeling Suite
# Usage: 
#    $AMSBIN/plams -f ZnO0001 polar_stabilization.py

s = Settings()
s.input.ams.Task = 'SinglePoint'
s.input.DFTB.Model = 'SCC-DFTB'
s.input.DFTB.ResourcesDir = 'DFTB.org/znorg-0-1'
s.input.DFTB.KSpace.Quality = 'Good'

mols = [Molecule('clean_good.xyz'), Molecule('vacancies_good.xyz'), Molecule('adsorbates_good.xyz')]

for mol in mols:
    job = AMSJob(settings=s, molecule=mol, name=mol.properties.name)
    job.run()
