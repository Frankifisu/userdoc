#!/usr/bin/env amspython
"""
    This file runs a UFF MD simulation of 32 Ar atoms in a box, recalculates a few snapshots with DFTB, and extracts
        * forces
        * relative energies
    from the DFTB calculations

    NOTE: if you do not have a DFTB license, change the `ref_settings` line below!

    To run this file, run 
    $AMSBIN/amspython generate_examples_folders.py

    Output directories:
        LJ_Ar, LJ_Ar_no_reference_data, LJ_Ar_validation_set, LJ_Ar_restart


"""
from scm.plams import Settings, AMSJob, Molecule, init, finish
from scm.params import ResultsImporter, LennardJonesParameters
import shutil
import os

def main():
    init()
    ref_settings = Settings()
    ref_settings.input.DFTB.Model = 'GFN1-xTB'
    ref_settings.input.DFTB.KSpace.Quality = 'GammaOnly'
    #ref_settings.input.ForceField.Type = 'UFF'    # NOTE: if you do not have a DFTB license, comment the above DFTB lines and uncomment this line.

    md_rkf = uff_md()
    ref_rkf = reference_job(md_rkf, ref_settings=ref_settings, frames=[3, 5, 7])
    create_yaml_files(ref_rkf)
    finish()


def uff_md():
    """ run UFF MD calculation, return path to ams.rkf """
    s = Settings()
    s.runscript.nproc = 1
    s.input.ams.rngseed = 314159
    s.input.ams.task = 'MolecularDynamics'
    s.input.ams.moleculardynamics.trajectory.samplingfreq = 10
    s.input.ams.moleculardynamics.timestep = 5
    s.input.ams.moleculardynamics.nsteps = 70
    s.input.ams.moleculardynamics.initialvelocities.temperature = 2000
    s.input.forcefield.type = 'UFF'

    md_job = AMSJob(settings=s, molecule=Molecule('Ar32.xyz'), name='uff_md')
    md_job.run()

    return md_job.results.rkfpath()


def reference_job(md_rkf, ref_settings, frames=False):
    """ Run reference calculations on some frames from the MD job, return resulting rkf. 
    md_rkf: path to an ams.rkf file
    ref_settings: Settings instance containing the reference engine settings
    frames: a list of integers """
    s = Settings()
    s.input.ams.task = 'Replay'
    if frames:
        # translates [1,2,3] to '1 2 3'
        s.input.ams.replay.frames = ' '.join(str(x) for x in frames)  
    s.input.ams.replay.file = md_rkf
    s.input.ams.properties.gradients = 'yes'

    ref_job = AMSJob(settings=s+ref_settings, name='reference_calculations')
    ref_job.run()

    return ref_job.results.rkfpath()

def get_parameter_interface():
    pi = LennardJonesParameters()
    pi['eps'].value = 3e-4     # Hartree
    pi['eps'].range = (1e-5, 1e-2)
    pi['rmin'].value = 4.0     # angstrom
    pi['rmin'].range = (1.0, 8.0)
    return pi

def create_yaml_files(ref_rkf):
    results_importer_settings = Settings()
    results_importer_settings.units.energy = 'eV'
    results_importer_settings.units.forces = 'eV/angstrom'

    ri = ResultsImporter(settings=results_importer_settings)
    ri.add_trajectory_singlepoints(ref_rkf, properties=['forces', 'relative_energies'], name='Ar32') 

    # typically one would simply call this store() method
    #ri.store(backup=False, binary=False)

    ### everything below is just to technically set up two different job_collection/training sets
    ### one with reference values (LJ_Ar), and one without (LJ_Ar_no_reference_data)

    # remove all metadata
    for x in ri.data_set:
        x.metadata = {}

    for x in ri.job_collection:
        ri.job_collection[x].metadata = {}

    data_set_copy = ri.data_set.copy()

    parameter_interface = get_parameter_interface()
    folder = 'LJ_Ar_no_reference_data'
    # remove reference values 
    for x in ri.data_set:
        x.reference = None
    ri.store(backup=False, binary=False, store_settings=False, folder=folder)
    parameter_interface.yaml_store(os.path.join(folder, 'parameter_interface.yaml'))

    ri.job_collection.engines = None

    for folder in ['LJ_Ar', 'LJ_Ar_restart']:
        ri.data_sets['training_set'] = data_set_copy # restore original data_set
        # remove reference engine ids 
        for x in ri.job_collection:
            ri.job_collection[x].reference_engine = None
        ri.store(backup=False, binary=False, store_settings=False, folder=folder)
        parameter_interface.yaml_store(os.path.join(folder, 'parameter_interface.yaml'))

    folder = 'LJ_Ar_validation_set'
    ri.data_sets['validation_set'] = ri.get_data_set('training_set').from_expressions(["forces('Ar32_frame001')"]).copy()
    for key in ri.get_data_set('validation_set').keys():
        del ri.data_sets['training_set'][key]
    ri.store(backup=False, binary=False, store_settings=False, folder=folder)
    parameter_interface.yaml_store(os.path.join(folder, 'parameter_interface.yaml'))

if __name__ == '__main__':
    main()

