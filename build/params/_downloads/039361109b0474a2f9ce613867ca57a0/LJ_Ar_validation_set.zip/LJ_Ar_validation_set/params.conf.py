training_set = 'training_set.yaml'
validation_set = 'validation_set.yaml'
job_collection = 'job_collection.yaml'
parameter_interface = 'parameter_interface.yaml'

### Define an optimizer for the optimization task. Use either a CMAOptimizer or Scipy
#optimizer = CMAOptimizer(sigma=0.1, popsize=10, minsigma=5e-4) 
optimizer = Scipy(method='Nelder-Mead')   # Nelder-Mead

### run the optimization in serial
parallel = ParallelLevels(parametervectors=1, jobs=1)

# log training set loss every 5 iterations
logger_every = 5

# evaluate (and log) validation set loss every 5 iterations
eval_every = 5
