This example illustrates how to fit a Lennard-Jones potential.

To run this example, open a terminal and run

$AMSBIN/params run

It should finish in less than a minute. The best parameters are stored in
optimization/trainingset_results/best/parameters_disk_representation.txt

You can also plot some results. Go to the
optimization/trainingset_results/best directory, and run

$AMSBIN/params plot predictions_forces.txt

This creates a correlation plot between the predicted forces and reference forces.

For more information about this example, see the online documentation.
