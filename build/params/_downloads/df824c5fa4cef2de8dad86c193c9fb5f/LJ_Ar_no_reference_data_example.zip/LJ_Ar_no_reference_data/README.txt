This example illustrates how to calculate trainingset.yaml reference values
with the help of an engine collection.

NOTE: This example requires that you have a DFTB license.

To run this example, open a terminal and run

$AMSBIN/params genref

It should finish in less than a minute. The reference calculations are stored
in the folder "reference.cache".

The new trainingset file including the reference values is called
"trainingset.ref.yaml"
