#!/usr/bin/env amspython

from scm.params import *

def main():
    job_collection = JobCollection('job_collection.yaml')
    data_set = DataSet('training_set.yaml')
    engine_collection = EngineCollection('engine_collection.yaml')

    dse = DataSetEvaluator()
    # 'saved_reference_calculations' is equivalent to 'reference.cache' from the `params genref` command
    dse.calculate_reference(job_collection, data_set, 
                            engine_collection, folder='saved_reference_calculations')

    # equivalent to 'training_set.ref.yaml' from the `params genref` command
    data_set.store('new_training_set.yaml') 


if __name__ == '__main__':
    main()
