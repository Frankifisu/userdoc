# Specify a restart file
optimizer = CMAOptimizer(restartfile='100/cmadata/restart.pkl') 

# When using a CMA restart file, the initial parameters do not influence the optimization, so there is no need to evaluate with them
skip_x0 = True

# Stop the optimization after 100 evaluations
max_evaluations = 100

