#!/bin/sh
rm -rf 100 200 restart_100
"$AMSBIN"/params --config 200.conf.py run --optdir 200
"$AMSBIN"/params --config 100.conf.py run --optdir 100
"$AMSBIN"/params --config restart_100.conf.py run --optdir restart_100
