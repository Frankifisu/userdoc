# Define a CMA optimizer
optimizer = CMAOptimizer(sigma=0.05, popsize=4, minsigma=5e-4, seed=314159) 

# Stop the optimization after 100 evaluations
max_evaluations = 100
