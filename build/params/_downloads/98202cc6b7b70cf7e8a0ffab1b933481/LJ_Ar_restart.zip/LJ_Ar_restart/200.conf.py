### Define an optimizer for the optimization task. Use either a CMAOptimizer or Scipy
optimizer = CMAOptimizer(sigma=0.05, popsize=4, minsigma=5e-4, seed=314159) 

### Stop the optimization after 200 evaluations
max_evaluations = 200
